# Modern UI pass — applied locally, not pushed to GitHub

Built from a live snapshot of `libraryofmiao/new-app` @ main. IMPORTANT: this
repo is being actively developed in real time — it changed structurally
several times in the few minutes it took to build this. Treat this as a
snapshot, not a guaranteed-current copy. An `ios/` directory that appeared
in the repo was intentionally NOT read or included, per instruction.

Material Components was already a project dependency, so no new
dependencies were added for this pass.

## What was already improving before I touched it (left alone)
The in-progress commits had already replaced the old emoji bottom-nav icons
(⌂ ⌕ ▣ ●) with real SVG icons rendered via `androidsvg`, generated from
`advanced_library_icons.zip` at build time. That system is untouched here —
it's good work already in flight.

## What this pass fixed

**A real visual bug**: the bottom nav's selected-tab label was set to
`Color.WHITE`, but the selected-tab highlight background is a *light* gray
(`Color.rgb(238, 235, 229)`ish) — white text on a near-white background was
essentially invisible. Changed the label color to the dark ink color so
it's actually readable when selected.

**Typography**: `styles.xml` set `android:fontFamily` to `"sans"`, which
isn't a valid Android font family name and silently fell back to default.
Fixed to `"sans-serif"`. All screen/section headlines and card titles now
use an explicit `sans-serif-medium` bold weight instead of the ambient
(broken) font + a bold flag.

**Inputs**: username, password, and catalogue search were plain `EditText`
with a hand-drawn background. Replaced with `TextInputLayout` +
`TextInputEditText`: floating labels, an outlined box, and a built-in
password show/hide toggle (there was previously no way to reveal the
password). Keyboard actions now work — "Done" submits login, "Search" runs
the catalogue search — both previously required tapping a button.

**Buttons**: custom `Button`s with hand-drawn `GradientDrawable`
backgrounds and `stateListAnimator = null` (no press feedback at all) are
now `MaterialButton`s — filled for primary actions, outlined for
secondary — with real ripple and elevation. This also fixes secondary
buttons being plain white with no border, indistinguishable from the white
cards around them.

**Cards**: the `card()` helper used a flat `FrameLayout` background. Now a
`MaterialCardView` with a subtle stroke and elevation; the catalogue result
cards (already clickable) get a proper ripple instead of none.

**Loading states**: plain "Loading…" text is now a small
`CircularProgressIndicator` next to the label, applied consistently to
Home, Catalogue, My Books, and Issue History.

**Motion**: subtle fade-ins on login and (unchanged) screen navigation.

**Manifest**: added `android:windowSoftInputMode="adjustResize"` so the
keyboard doesn't cover the new input fields.

## Not changed
- The bottom navigation bar's structure/icons (already being modernized
  upstream — see above)
- Any network calls, JSON parsing, caching (IssuedBooksCache), or
  due-date notification logic
- The `ios/` directory — not read, not included

## Build in GitHub Codespaces / VS Code

```
chmod +x ./gradlew
./gradlew :app:assembleDebug --stacktrace
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

Note: the build's `preBuild` step reads `advanced_library_icons.zip` from
the project root to generate the launcher icon and nav icon assets — that
file is included in this zip at the root, required for the build to
configure correctly.
